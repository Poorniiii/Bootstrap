﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CourseService.Models
{
    public class Brands
    {
        public string BrandId { get; set; }
        public string Name { get; set; }
    }
}